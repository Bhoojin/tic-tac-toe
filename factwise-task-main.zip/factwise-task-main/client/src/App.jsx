import TicTacToe from './components/TicTacToe';
import './index.css';

function App() {
  return (
    <div className="App">
      <TicTacToe />
    </div>
  );
}

export default App;
